import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, Globe, HelpCircle, LogOut, Sun, Moon, Monitor, ChevronUp, ChevronDown } from 'lucide-react';

export function UserProfile() {
  const [isOpen, setIsOpen] = useState(false);
  const [themePreference, setThemePreference] = useState<'system' | 'light' | 'dark'>('system');
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  return (
    <div className="relative" ref={menuRef}>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full mb-2 left-0 w-full bg-white/[0.08] backdrop-blur-3xl border border-white/20 rounded-2xl shadow-[0_16px_40px_rgb(0,0,0,0.6)] p-2 z-50 origin-bottom-left"
          >
            {/* Header: Project context */}
            <div className="flex items-center gap-3 p-2 mb-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-rose-500 via-fuchsia-500 to-indigo-500 shrink-0"></div>
              <div className="flex flex-col shrink-0">
                <span className="text-white font-medium text-sm">Lakshay's Project</span>
                <span className="text-gray-400 text-xs">Owner &bull; 1 member</span>
              </div>
            </div>

            <div className="h-px w-full bg-white/5 my-1" />

            <div className="py-1">
              <MenuItem icon={<Settings className="w-4 h-4" />} label="Account Settings" />
              <MenuItem icon={<Globe className="w-4 h-4" />} label="Language" />
              <MenuItem icon={<HelpCircle className="w-4 h-4" />} label="Help Center" />
            </div>

            <div className="h-px w-full bg-white/5 my-1" />

            <div className="flex items-center justify-between p-2 mt-1">
              <button className="flex items-center gap-2 text-red-500 hover:bg-red-500/10 px-2 py-1.5 rounded-lg transition-colors text-sm font-medium">
                <LogOut className="w-4 h-4" />
                Logout
              </button>
              
              <div className="flex items-center bg-[#2A2A2E] rounded-full p-0.5">
                <ThemeButton 
                  icon={<Sun className="w-3.5 h-3.5" />} 
                  active={themePreference === 'light'} 
                  onClick={() => setThemePreference('light')} 
                />
                <ThemeButton 
                  icon={<Monitor className="w-3.5 h-3.5" />} 
                  active={themePreference === 'system'} 
                  onClick={() => setThemePreference('system')} 
                />
                <ThemeButton 
                  icon={<Moon className="w-3.5 h-3.5" />} 
                  active={themePreference === 'dark'} 
                  onClick={() => setThemePreference('dark')} 
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between px-2 py-2 w-full hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-orange-800/80 text-orange-200 flex items-center justify-center font-medium text-sm shrink-0">
            L
          </div>
          <div className="flex flex-col items-start min-w-0">
            <span className="text-sm font-medium text-white truncate w-full">Lakshay Yadav</span>
            <span className="text-xs text-gray-500 truncate w-full">lakshay210yadav@gmail.com</span>
          </div>
        </div>
        <div className="w-6 h-6 shrink-0 rounded flex items-center justify-center hover:bg-white/10 text-gray-400">
          {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </div>
      </div>
    </div>
  );
}

function MenuItem({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <button className="w-full flex items-center gap-3 px-2 py-2 rounded-lg text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-colors">
      <span className="text-gray-400">{icon}</span>
      {label}
    </button>
  );
}

function ThemeButton({ icon, active, onClick }: { icon: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`p-1.5 rounded-full transition-colors ${active ? 'bg-[#3F3F46] text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
    >
      {icon}
    </button>
  );
}
