import React, { useState, useEffect } from 'react';

export function Greeting() {
  const [greeting, setGreeting] = useState('');
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    const hour = new Date().getHours();
    let text = 'WELCOME';
    if (Math.random() > 0.4 && hour >= 5 && hour <= 23) {
      if (hour >= 5 && hour < 12) text = 'GOOD MORNING';
      else if (hour >= 12 && hour < 17) text = 'GOOD AFTERNOON';
      else if (hour >= 17 && hour < 22) text = 'GOOD EVENING';
    }
    setGreeting(`${text}, LAKSHAY`);
  }, []);

  useEffect(() => {
    if (!greeting) return;
    let i = 0;
    const interval = setInterval(() => {
      setDisplayedText(greeting.slice(0, i + 1));
      i++;
      if (i > greeting.length) {
        clearInterval(interval);
      }
    }, 60); // fast typing speed
    return () => clearInterval(interval);
  }, [greeting]);

  if (!greeting) return null;

  return (
    <div className="mb-6 font-mono tracking-widest text-[#E2E8F0] text-sm md:text-base uppercase flex items-center justify-center gap-2" style={{ letterSpacing: '0.25em' }}>
      <span className="opacity-70">&gt;</span>
      <span style={{ textShadow: '0 0 8px rgba(226,232,240,0.3)' }}>{displayedText}</span>
      <span className="w-2 h-4 bg-[#E2E8F0] animate-pulse"></span>
    </div>
  );
}
