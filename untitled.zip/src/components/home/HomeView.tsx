import React from 'react';
import { PromptInput } from '../ui/PromptInput';
import { motion } from 'motion/react';
import { Greeting } from './Greeting';

interface HomeViewProps {
  onMenuClick: () => void;
  onStart: (prompt: string) => void;
}

export function HomeView({ onMenuClick, onStart }: HomeViewProps) {
  return (
    <div className="flex-1 flex flex-col relative overflow-hidden h-full bg-[#0A0612]">
      {/* Background Effects - Deep Purple Gradient */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[60%] bg-gradient-to-b from-[#1E0B38]/80 to-transparent mix-blend-screen opacity-90" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-700/10 blur-[120px] rounded-full mix-blend-screen" />
        <div className="absolute -top-[20%] left-1/4 w-[800px] h-[700px] bg-fuchsia-900/20 blur-[130px] rounded-full mix-blend-screen" />
      </div>

      {/* Header */}
      <header className="h-16 flex items-center justify-between px-4 shrink-0 relative z-10 w-full">
        <div className="flex items-center gap-3">
          <button 
            onClick={onMenuClick}
            className="w-11 h-11 shrink-0 flex items-center justify-center text-gray-200 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-colors backdrop-blur-sm"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 8h14" />
              <path d="M5 16h8" />
            </svg>
          </button>
          <div className="flex items-center font-bold text-xl tracking-tight">
            thinkply
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="hidden sm:flex px-4 py-1.5 rounded-full border border-white/10 text-sm font-medium hover:bg-white/5 transition-all">
            Log in
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 md:px-8 relative z-10 w-full mb-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-4xl w-full"
        >
          <Greeting />
          <h1 className="text-4xl sm:text-5xl md:text-[56px] font-semibold tracking-tight mb-5 text-[#F8FAFC]">
            Turn Ideas Into Reality
          </h1>
          <p className="text-base md:text-[17px] text-gray-400 mb-12 max-w-2xl mx-auto font-medium">
            Build websites by simply chatting.
          </p>

          <div className="w-full max-w-3xl mx-auto relative relative z-20">
            <PromptInput onSubmit={onStart} />
          </div>
        </motion.div>
      </main>
    </div>
  );
}
