import React, { useState, useRef, useEffect } from 'react';
import { Mic, ArrowUp, Plus, Sparkles, Settings, ChevronDown, SlidersHorizontal } from 'lucide-react';
import { motion } from 'motion/react';
import { AdvancedControlsModal } from './AdvancedControlsModal';
import { AgentState } from '../../App';

const PLACEHOLDERS = [
  "Build me a modern portfolio website",
  "Create a landing page for my startup",
  "Design a personal blog website",
  "Make a dashboard for analytics app",
  "Build a weather app UI",
  "Create a todo list application",
  "Design a social media feed UI",
  "Build a chat application interface",
  "Make a cryptocurrency tracker app",
  "Create a food delivery app UI",
  "Build an e-commerce store website",
  "Design a login/signup page",
  "Create a landing page for AI tool",
  "Build a task management board like Trello",
  "Make a fitness tracking app UI",
  "Create a travel booking website",
  "Design a restaurant website homepage",
  "Build a job portal platform UI",
  "Make a real estate listing website",
  "Create a music player web app",
  "Build a note-taking application",
  "Design a school management dashboard",
  "Create a resume builder website",
  "Make a code editor UI",
  "Build a video conferencing app UI",
  "Design a banking dashboard",
  "Create a learning platform UI",
  "Build a calendar scheduling app",
  "Make an expense tracker app",
  "Design a car rental website",
  "Create a news website homepage",
  "Build a movie review app",
  "Design a SaaS landing page",
  "Make a product showcase website",
  "Create an admin dashboard UI",
  "Build a survey form builder",
  "Design a fitness gym website",
  "Make a podcast streaming UI",
  "Create a community forum platform",
  "Build a weather forecast dashboard",
  "Design a dark mode dashboard UI",
  "Create a mobile app landing page",
  "Build a crypto exchange UI",
  "Make a portfolio for developer",
  "Create a freelance marketplace UI",
  "Build a CRM dashboard system",
  "Make an online learning LMS platform",
  "Create a photo gallery website",
  "Build a startup pitch landing page",
  "Design an online store UI"
];

interface PromptInputProps {
  onSubmit: (text: string) => void;
  compact?: boolean;
  agentState?: AgentState;
}

export function PromptInput({ onSubmit, compact = false, agentState = 'initial' }: PromptInputProps) {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [currentPlaceholder, setCurrentPlaceholder] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    if (compact) {
      setCurrentPlaceholder("");
      return;
    }
    
    if (isDeleting) {
      if (currentPlaceholder.length === 0) {
        setIsDeleting(false);
        setPlaceholderIndex((prev) => (prev + 1) % PLACEHOLDERS.length);
        timeout = setTimeout(() => {}, 500);
      } else {
        timeout = setTimeout(() => {
          setCurrentPlaceholder(currentPlaceholder.slice(0, -1));
        }, 15);
      }
    } else {
      if (currentPlaceholder === PLACEHOLDERS[placeholderIndex]) {
        timeout = setTimeout(() => {
          setIsDeleting(true);
        }, 2000);
      } else {
        timeout = setTimeout(() => {
          setCurrentPlaceholder(PLACEHOLDERS[placeholderIndex].slice(0, currentPlaceholder.length + 1));
        }, 30);
      }
    }
    return () => clearTimeout(timeout);
  }, [currentPlaceholder, isDeleting, placeholderIndex, compact]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'inherit';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [text]);

  const handleSubmit = () => {
    if (text.trim()) {
      onSubmit(text);
      if (compact) {
          setText('');
      } else {
         setText('');
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  let statusText = "Agent is ready";
  let statusColor = "bg-green-500";
  let pingColor = "bg-green-400";
  let animatePing = false;

  switch (agentState) {
    case 'waking':
      statusText = "Agent is waking up...";
      statusColor = "bg-yellow-500";
      pingColor = "bg-yellow-400";
      animatePing = true;
      break;
    case 'running':
      statusText = "Agent is running...";
      statusColor = "bg-green-500";
      pingColor = "bg-green-400";
      animatePing = true;
      break;
    case 'waiting':
      statusText = "Agent is waiting...";
      statusColor = "bg-blue-500";
      pingColor = "bg-blue-400";
      animatePing = false;
      break;
    case 'sleeping':
      statusText = "Agent is sleeping...";
      statusColor = "bg-gray-500";
      pingColor = "bg-gray-400";
      animatePing = false;
      break;
    default:
      break;
  }

  return (
    <>
      <div className={`relative flex flex-col w-full border border-white/10 transition-all bg-white/[0.05] backdrop-blur-xl shadow-2xl ${compact ? 'rounded-[32px] px-5 py-3.5' : 'rounded-3xl p-4'}`}>
        {compact && agentState !== 'initial' && (
          <div className="flex items-center gap-2 px-1 pb-2 transition-all">
            <div className="relative flex h-2.5 w-2.5">
              {animatePing && <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${pingColor} opacity-75`}></span>}
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${statusColor}`}></span>
            </div>
            <span className="text-[13px] font-medium text-gray-400">{statusText}</span>
          </div>
        )}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={compact ? "Message Agent" : currentPlaceholder}
          className={`w-full bg-transparent border-none focus:ring-0 resize-none text-white placeholder-gray-500 outline-none max-h-[150px] overflow-y-auto custom-scrollbar ${compact ? 'text-base px-1 py-0.5 mt-1' : 'text-lg p-1'}`}
          rows={1}
          style={{ minHeight: compact ? '24px' : '44px' }}
        />
        
        <div className={`flex items-center justify-between ${compact ? 'mt-2' : 'mt-3 border-t border-white/5 pt-3'}`}>
          <div className="flex flex-wrap items-center gap-2">
            <button className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors">
              <Plus className="w-4 h-4" />
            </button>

            {!compact && (
              <button className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 text-gray-300 hover:bg-white/5 transition-colors text-sm">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Design System</span>
                <ChevronDown className="w-3 h-3" />
              </button>
            )}
          </div>
          
          <div className="flex items-center gap-1.5">
            {!compact && (
              <>
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white transition-colors cursor-pointer"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </>
            )}
            <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white transition-colors cursor-pointer">
              <Mic className="w-4 h-4" />
            </button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSubmit}
              disabled={!text.trim()}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                text.trim() ? 'bg-indigo-600 text-white hover:bg-indigo-500' : 'bg-white/10 text-gray-400'
              }`}
            >
              <ArrowUp className="w-5 h-5" />
            </motion.button>
          </div>
        </div>
      </div>
      
      <AdvancedControlsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />
    </>
  );
}
