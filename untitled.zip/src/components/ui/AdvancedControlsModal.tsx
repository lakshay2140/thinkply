import React, { useState } from 'react';
import { X, Sparkles, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdvancedControlsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AdvancedControlsModal({ isOpen, onClose }: AdvancedControlsModalProps) {

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm z-50 overflow-hidden"
          >
            <div className="bg-white/5 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 flex flex-col font-sans text-gray-200">
              
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-white/5">
                <button className="opacity-0 cursor-default p-2">
                   <ChevronRight className="w-5 h-5" />
                </button>
                <h2 className="text-lg font-semibold tracking-tight text-white">Advanced Controls</h2>
                <button onClick={onClose} className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-gray-400 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Content */}
              <div className="p-4 space-y-5">
                
                {/* Maxx toggle */}
                <div className="flex items-center justify-between bg-white/5 p-3.5 rounded-xl border border-white/5">
                  <div className="flex items-center gap-2">
                    <div className="bg-slate-800 rounded-full p-1 text-white">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-white text-[15px] italic">Maxx <span className="text-blue-400 not-italic">✨</span></span>
                  </div>
                  <button className="w-11 h-6 bg-gray-600 rounded-full relative transition-colors duration-200 ease-in-out focus:outline-none">
                     <div className="w-5 h-5 bg-white rounded-full absolute left-0.5 top-0.5 shadow-sm transform transition-transform duration-200 ease-in-out translate-x-0" />
                  </button>
                </div>

                <div className="space-y-1">
                  <div className="text-xs font-medium text-gray-400 uppercase tracking-wider px-1">Select Model</div>
                  <button className="w-full flex items-center justify-between p-3.5 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 text-orange-400 opacity-80">
                         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="12" y1="2" x2="12" y2="22" />
                            <line x1="2" y1="12" x2="22" y2="12" />
                            <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
                            <line x1="4.93" y1="19.07" x2="19.07" y2="4.93" />
                         </svg>
                      </div>
                      <span className="font-medium text-[15px] text-white">Claude 4.7 Opus</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-500" />
                  </button>
                </div>



              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
