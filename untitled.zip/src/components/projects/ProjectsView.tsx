import React, { useState, useEffect, useRef } from 'react';
import { Search, Plus } from 'lucide-react';
import { AnimatePresence } from 'motion/react';
import { Project } from '../../types';
import { DUMMY_PROJECTS } from '../../data/projects';
import { ProjectCard } from './ProjectCard';
import { RenameDialog } from './RenameDialog';
import { DeleteDialog } from './DeleteDialog';

export function ProjectsView({ onMenuClick, filter = 'all' }: { onMenuClick: () => void, filter?: 'all' | 'starred' }) {
  const [projects, setProjects] = useState<Project[]>(DUMMY_PROJECTS);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  
  const [renameProject, setRenameProject] = useState<Project | null>(null);
  const [deleteProject, setDeleteProject] = useState<Project | null>(null);

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, [filter]);

  useEffect(() => {
    const handleClickOutside = () => {
      setActiveMenuId(null);
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const handleToggleStar = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setProjects(projects.map(p => p.id === id ? { ...p, isStarred: !p.isStarred } : p));
  };

  const handleDelete = () => {
    if (deleteProject) {
      setProjects(projects.filter(p => p.id !== deleteProject.id));
    }
    setDeleteProject(null);
  };

  const handleRename = (newName: string) => {
    if (renameProject && newName.trim()) {
      setProjects(projects.map(p => 
        p.id === renameProject.id 
          ? { ...p, name: newName.trim() } 
          : p
      ));
    }
    setRenameProject(null);
  };

  // Filter combined
  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filter === 'starred' ? p.isStarred : true;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-[#0A0A0A] custom-scrollbar flex flex-col h-full relative">
      {/* Colorful Background Orbs for Glassmorphism */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-purple-600/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-600/20 blur-[120px]" />
      </div>

      <header className="h-16 flex items-center px-4 md:px-6 shrink-0 relative z-10 w-full border-b border-white/5 bg-black/20 backdrop-blur-xl top-0 sticky">
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onMenuClick();
          }}
          className="w-11 h-11 shrink-0 flex items-center justify-center text-gray-200 hover:text-white rounded-full bg-[#242424] hover:bg-[#2F2F2F] transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 8h14" />
            <path d="M5 16h8" />
          </svg>
        </button>
        <div className="ml-4 flex items-center font-bold text-xl tracking-tight">
          thinkply
        </div>
      </header>

      <div className="max-w-6xl mx-auto w-full p-4 md:p-8 relative z-10">
        {isLoading ? (
          <div>
            <h1 className="text-3xl font-semibold mb-6">
              {filter === 'starred' ? 'Starred projects' : 'All projects'}
            </h1>
            <div className="max-w-md w-full mb-8 relative">
              <div className="w-full h-10 bg-[#1e1e24] rounded-lg animate-pulse" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i}>
                  <div className="aspect-video bg-[#1e1e24] rounded-xl animate-pulse" />
                  <div className="mt-3">
                    <div className="h-4 w-2/3 bg-[#1e1e24] rounded animate-pulse" />
                    <div className="h-3 w-1/3 bg-[#1e1e24] rounded mt-2 animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
              <h1 className="text-3xl font-semibold">
                {filter === 'starred' ? 'Starred projects' : 'All projects'}
              </h1>
              <div className="flex items-center gap-3 w-full md:w-auto">
                <div className="relative w-full md:w-64">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input 
                    type="text" 
                    placeholder="Search for a project" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#18181A] border border-white/10 rounded-lg py-2 pl-9 pr-4 text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white/50"
                  />
                </div>
                <button className="bg-white hover:bg-gray-200 text-black font-semibold text-sm px-4 py-2 rounded-lg flex items-center gap-2 whitespace-nowrap transition-colors">
                  <Plus className="w-4 h-4" />
                  Create project
                </button>
              </div>
            </div>

            <div>
              {filteredProjects.length === 0 ? (
                <div className="text-gray-500 py-12 text-center">
                  No projects found.
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                  {filteredProjects.map(project => (
                    <div key={project.id}>
                      <ProjectCard 
                        project={project}
                        activeMenuId={activeMenuId}
                        onToggleMenu={(id, e) => {
                          e.stopPropagation();
                          setActiveMenuId(activeMenuId === id ? null : id);
                        }}
                        onCloseMenu={() => setActiveMenuId(null)}
                        onToggleStar={handleToggleStar}
                        onRename={(p) => setRenameProject(p)}
                        onDelete={(p) => setDeleteProject(p)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <AnimatePresence>
        {renameProject && (
          <RenameDialog 
            project={renameProject} 
            onClose={() => setRenameProject(null)} 
            onRename={handleRename} 
          />
        )}
        {deleteProject && (
          <DeleteDialog 
            project={deleteProject} 
            onClose={() => setDeleteProject(null)} 
            onConfirm={handleDelete} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
