import React, { useRef } from 'react';
import { MoreHorizontal, ExternalLink, Edit2, Star, Trash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Project } from '../../types';

interface ProjectCardProps {
  project: Project;
  activeMenuId: string | null;
  onToggleMenu: (id: string, e: React.MouseEvent) => void;
  onCloseMenu: () => void;
  onToggleStar: (id: string, e: React.MouseEvent) => void;
  onRename: (project: Project) => void;
  onDelete: (project: Project) => void;
}

export function ProjectCard({ 
  project, 
  activeMenuId, 
  onToggleMenu, 
  onCloseMenu, 
  onToggleStar,
  onRename,
  onDelete
}: ProjectCardProps) {
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside handled by parent

  return (
    <>
      <div className="aspect-video bg-white/[0.02] backdrop-blur-3xl hover:bg-white/[0.06] hover:border-white/20 transition-all rounded-[20px] flex items-center justify-center border border-white/10 relative group cursor-pointer overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.12)] p-1.5 glass-panel">
        {project.hasPreview ? (
          <div className="w-full h-full bg-[#FAFAFA] rounded-xl overflow-hidden p-3 relative">
             <div className="absolute top-0 left-0 w-full h-4 bg-gray-100 flex items-center px-2 space-x-1 border-b border-gray-200">
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
             </div>
             <div className="mt-4 w-6 h-6 rounded-full bg-[#FF4747] mx-auto mb-2"></div>
             <div className="h-2 w-24 bg-gray-300 mx-auto rounded-full"></div>
             <div className="h-1.5 w-16 bg-gray-200 mx-auto rounded-full mt-1.5"></div>
          </div>
        ) : (
          <div className="w-full h-full rounded-xl bg-white/5 flex flex-col p-3 space-y-3 opacity-60">
            <div className="flex items-center space-x-2 border-b border-white/5 pb-2">
               <div className="w-3 h-3 bg-white/10 rounded-full animate-pulse"></div>
               <div className="h-2 w-16 bg-white/10 rounded-sm animate-pulse"></div>
            </div>
            <div className="flex-1 bg-white/[0.02] rounded-md p-2.5 space-y-2.5 border border-white/5">
               <div className="h-2 w-3/4 bg-white/10 rounded-sm animate-pulse"></div>
               <div className="h-2 w-1/2 bg-white/10 rounded-sm animate-pulse flex-1"></div>
               <div className="h-2 w-5/6 bg-white/10 rounded-sm animate-pulse"></div>
               <div className="h-8 w-2/3 bg-white/5 rounded-md mt-auto mx-auto translate-y-3 animate-pulse"></div>
            </div>
          </div>
        )}
        <button 
          onClick={(e) => onToggleStar(project.id, e)}
          className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 flex flex-col items-center justify-center text-gray-400 hover:text-white transition-colors"
        >
          <Star className={`w-3.5 h-3.5 ${project.isStarred ? 'fill-yellow-500 text-yellow-500' : ''}`} />
        </button>
      </div>
      <div className="mt-3 flex items-start justify-between">
        <div>
          <h3 className="text-sm font-medium text-white truncate max-w-[150px]">{project.name}</h3>
          <p className="text-xs text-gray-500 mt-1">{project.date}</p>
        </div>
        <div className="relative">
          <button 
            onClick={(e) => onToggleMenu(project.id, e)}
            className="p-1 text-gray-400 hover:text-white"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
          
          <AnimatePresence>
            {activeMenuId === project.id && (
              <motion.div 
                ref={menuRef}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.1 }}
                // using stop propagation and prevent default is handled inside onClick
                className="absolute right-0 top-full mt-1 w-48 bg-white/[0.05] backdrop-blur-3xl border border-white/10 rounded-xl shadow-[0_16px_40px_rgb(0,0,0,0.5)] overflow-hidden z-30 py-1"
              >
                <DropdownItem icon={<ExternalLink className="w-4 h-4" />} label="Open" onClick={(e) => { e.stopPropagation(); onCloseMenu(); }} />
                <DropdownItem icon={<Edit2 className="w-4 h-4" />} label="Rename" onClick={(e) => { e.stopPropagation(); onRename(project); onCloseMenu(); }} />
                <DropdownItem icon={<Star className="w-4 h-4" />} label={project.isStarred ? 'Unstar project' : 'Star project'} onClick={(e) => { e.stopPropagation(); onToggleStar(project.id, e); onCloseMenu(); }} />
                <div className="bg-white/10 h-px w-full my-1" />
                <DropdownItem icon={<Trash className="w-4 h-4" />} label="Delete" onClick={(e) => { e.stopPropagation(); onDelete(project); onCloseMenu(); }} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
}

function DropdownItem({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: (e: React.MouseEvent) => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
    >
      <span className="text-gray-400">{icon}</span>
      {label}
    </button>
  );
}
