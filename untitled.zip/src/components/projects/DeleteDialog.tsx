import React from 'react';
import { X, Trash } from 'lucide-react';
import { motion } from 'motion/react';
import { Project } from '../../types';

interface DeleteDialogProps {
  project: Project;
  onClose: () => void;
  onConfirm: () => void;
}

export function DeleteDialog({ project, onClose, onConfirm }: DeleteDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl w-full max-w-sm p-6 relative z-10 shadow-2xl"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 mb-4">
            <Trash className="w-6 h-6" />
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <h3 className="text-xl font-semibold text-white mb-2">Delete Project?</h3>
        <p className="text-gray-400 text-sm mb-6">
          You are about to delete <span className="text-white font-medium">{project.name}</span>.
          <br /><br />
          This action cannot be undone.
        </p>
        
        <div className="flex justify-end gap-3 p-4 -mx-6 -mb-6 border-t border-white/10 bg-black/20 backdrop-blur-xl rounded-b-2xl">
          <button 
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg text-sm font-medium border border-white/10 text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={onConfirm}
            className="bg-red-500 hover:bg-red-600 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors"
          >
            Delete
          </button>
        </div>
      </motion.div>
    </div>
  );
}
