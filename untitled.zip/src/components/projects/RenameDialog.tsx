import React, { useState } from 'react';
import { X } from 'lucide-react';
import { motion } from 'motion/react';
import { Project } from '../../types';

interface RenameDialogProps {
  project: Project;
  onClose: () => void;
  onRename: (newName: string) => void;
}

export function RenameDialog({ project, onClose, onRename }: RenameDialogProps) {
  const [name, setName] = useState(project.name);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl w-full max-w-sm p-5 relative z-10 shadow-2xl"
      >
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-white">Rename project</h3>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <input 
          autoFocus
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onRename(name)}
          className="w-full bg-transparent border-2 border-indigo-500 rounded-lg py-2.5 px-3 text-white focus:outline-none focus:ring-0"
        />
        <div className="flex justify-end gap-3 mt-6">
          <button 
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={() => onRename(name)}
            disabled={!name.trim()}
            className="bg-white hover:bg-gray-200 text-black px-4 py-2 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
          >
            Rename
          </button>
        </div>
      </motion.div>
    </div>
  );
}
