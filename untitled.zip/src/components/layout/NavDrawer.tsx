import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home, LayoutGrid, Star, Clock, X, ChevronDown, Search } from 'lucide-react';
import { UserProfile } from '../user/UserProfile';

interface NavDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: 'home' | 'projects' | 'starred') => void;
  currentView: 'home' | 'editing' | 'projects' | 'starred';
}

export function NavDrawer({ isOpen, onClose, onNavigate, currentView }: NavDrawerProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/20 z-40 backdrop-blur-sm"
          />
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', bounce: 0, duration: 0.3 }}
            className="fixed top-0 left-0 bottom-0 w-[280px] bg-white/[0.05] backdrop-blur-2xl backdrop-saturate-150 border-r border-white/10 z-50 flex flex-col text-gray-300 shadow-[20px_0_40px_rgb(0,0,0,0.3)]"
          >
            {/* Search Input */}
            <div className="p-4 pt-6">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Search" 
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-2.5 pl-9 pr-4 text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 backdrop-blur-md transition-all"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto py-2 px-3 flex flex-col gap-6 custom-scrollbar">
              {/* Primary Nav */}
              <div className="flex flex-col gap-1">
                <NavItem 
                  icon={<Home className="w-4 h-4" />} 
                  label="Home" 
                  active={currentView === 'home' || currentView === 'editing'}
                  onClick={() => {
                    onNavigate('home');
                    onClose();
                  }}
                />
                <NavItem 
                  icon={<LayoutGrid className="w-4 h-4" />} 
                  label="Projects" 
                  active={currentView === 'projects'}
                  onClick={() => {
                    onNavigate('projects');
                    onClose();
                  }}
                />
                <NavItem 
                  icon={<Star className="w-4 h-4" />} 
                  label="Starred projects" 
                  active={currentView === 'starred'}
                  onClick={() => {
                    onNavigate('starred');
                    onClose();
                  }}
                />
              </div>
            </div>
            
            {/* User Profile */}
            <div className="p-2 border-t border-white/10 mt-auto">
              <UserProfile />
            </div>

            {/* Close button */}
            <motion.button 
              exit={{ opacity: 0, transition: { duration: 0 } }}
              onClick={onClose}
              className="absolute top-4 -right-14 w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white backdrop-blur-2xl backdrop-saturate-150 shadow-[0_8px_32px_rgb(0,0,0,0.5)] z-[60]"
            >
              <X className="w-5 h-5" />
            </motion.button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function NavItem({ icon, label, active = false, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) {
  return (
    <div 
      onClick={onClick}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all duration-200 ${
      active 
        ? 'bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.1)]' 
        : 'text-gray-400 hover:bg-white/10 hover:text-white border border-transparent'
    }`}>
      {icon}
      <span className="text-sm">{label}</span>
    </div>
  );
}
