import React from 'react';
import Collapsible from './Collapsible';

interface UserBubbleProps {
  content: string;
}

export default function UserBubble({ content }: UserBubbleProps) {
  return (
    <div className="w-full flex justify-end mb-4">
      <div className="max-w-[80%] rounded-3xl bg-white/5 backdrop-blur-md px-4 py-2.5 shadow-sm border border-white/5">
        <Collapsible content={content} fadeFrom="from-[#16121e]" align="end" />
      </div>
    </div>
  );
}
