import { X, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface ExportPromptModalProps {
  onClose: () => void;
}

export function ExportPromptModal({ onClose }: ExportPromptModalProps) {
  const [copied, setCopied] = useState(false);

  const promptText = `
You are an expert AI software assistant. I am building a React application using Vite and Tailwind CSS.
Whenever I ask you to create or modify code, you MUST output your response strictly using the following XML-like format. 

Use the <boltArtifact> tag to wrap all changes. 
Inside the <boltArtifact>, use <boltAction> tags for each file.

Format:
<boltArtifact id="project-update" title="Update Application">
  <boltAction type="file" filePath="src/App.tsx">
    // Complete file content here
  </boltAction>
</boltArtifact>

Supported action types are "file" (for creating or completely replacing a file) and "shell" (for running commands like npm install).

Please write only pure code without markdown wrap inside the boltAction tag, OR use markdown wrap inside the boltAction tag (it will be stripped automatically).
  `.trim();

  const handleCopy = () => {
    navigator.clipboard.writeText(promptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-[#1e1e20] border border-white/10 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">System Prompt for Other AIs</h2>
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto flex-1">
          <p className="text-sm text-gray-300 mb-4">
            Copy this prompt and paste it into ChatGPT, Claude, or Google AI Studio. 
            When they reply, simply copy their entire response and paste it into the chat panel here to automatically build your app!
          </p>
          
          <div className="relative group">
            <pre className="text-sm text-gray-300 bg-black/50 p-4 rounded-xl border border-white/5 whitespace-pre-wrap font-mono relative overflow-hidden">
              {promptText}
            </pre>
            <button 
              onClick={handleCopy}
              className="absolute top-2 right-2 p-2 bg-white/10 backdrop-blur-md rounded-lg border border-white/10 text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 hover:bg-white/20"
            >
              {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
              <span className="text-xs font-medium">{copied ? "Copied!" : "Copy Prompt"}</span>
            </button>
          </div>
        </div>
        
        <div className="p-4 border-t border-white/10 bg-white/5 flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
