import React, { useState } from 'react';
import { Share, Eye, X, BookOpen } from 'lucide-react';
import { ChatPanel } from './ChatPanel';
import { PreviewPanel } from './PreviewPanel';
import { ExportPromptModal } from './ExportPromptModal';
import { Message } from '../../types';
import { AgentState } from '../../App';

interface EditorViewProps {
  onMenuClick: () => void;
  messages: Message[];
  onSendMessage: (text: string, existingMessages: Message[]) => void;
  files: Record<string, string>;
  setFiles: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  projectName: string;
  setProjectName: React.Dispatch<React.SetStateAction<string>>;
  agentState: AgentState;
  isNavOpen: boolean;
}

export function EditorView({ onMenuClick, messages, onSendMessage, files, setFiles, projectName, setProjectName, agentState, isNavOpen }: EditorViewProps) {
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#0A0612] relative">
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[60%] bg-gradient-to-b from-[#1E0B38]/60 to-transparent mix-blend-screen opacity-90" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-700/10 blur-[120px] rounded-full mix-blend-screen" />
      </div>

      {/* Floating Menu Toggle Button */}
      {!isPreviewOpen && !isNavOpen && (
        <div className="absolute top-4 left-4 z-40">
          <button 
            onClick={onMenuClick}
            className="w-10 h-10 flex items-center justify-center text-gray-300 hover:text-white rounded-full bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 hover:scale-105 active:scale-95 transition-all shadow-lg backdrop-blur-md cursor-pointer"
            title="Open Menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 8h14" />
              <path d="M5 16h8" />
            </svg>
          </button>
        </div>
      )}

      {/* Floating Center Project Name Capsule */}
      {!isPreviewOpen && !isNavOpen && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-40 max-w-[calc(100%-110px)] sm:max-w-xs md:max-w-md pointer-events-auto">
          <div className="flex items-center justify-center gap-1.5 text-white border border-white/10 rounded-full px-4 py-2 bg-white/5 backdrop-blur-md shadow-lg">
            <span className="font-bold text-sm tracking-tight truncate select-none" title={projectName}>
              {projectName}
            </span>
            <button className="shrink-0 text-gray-500 hover:text-indigo-400 hover:scale-110 active:scale-95 transition-all cursor-pointer" title="Rename project">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Floating Right Controls (Preview / Share) */}
      {!isPreviewOpen && !isNavOpen && (
        <div className="absolute top-4 right-4 z-40 flex items-center gap-2">
          <button 
            onClick={() => setIsPromptModalOpen(true)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-300 hover:text-white bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 rounded-full hover:scale-105 active:scale-95 transition-all shadow-lg backdrop-blur-md cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            Prompt Others
          </button>
          <button className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-300 hover:text-white bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 rounded-full hover:scale-105 active:scale-95 transition-all shadow-lg backdrop-blur-md cursor-pointer">
            <Share className="w-4 h-4" />
            Share
          </button>
          <button 
            onClick={() => setIsPreviewOpen(true)}
            className="flex items-center justify-center gap-1.5 w-10 h-10 sm:w-auto sm:px-4 sm:py-2 text-sm font-medium rounded-full bg-white/5 text-white border border-white/10 hover:border-white/20 hover:bg-white/10 transition-all shadow-lg backdrop-blur-md cursor-pointer hover:scale-105 active:scale-95"
            title="Open Preview"
          >
            <Eye className="w-4 h-4" />
            <span className="hidden sm:inline">Preview</span>
          </button>
        </div>
      )}

      {isPromptModalOpen && (
        <ExportPromptModal onClose={() => setIsPromptModalOpen(false)} />
      )}

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden relative z-10 bg-transparent">
        {/* Left Panel: Chat */}
        <div className={`${isPreviewOpen ? 'hidden' : 'w-full'} shrink-0 flex flex-col bg-transparent z-10 transition-all border-r border-white/10`}>
          <ChatPanel 
             messages={messages} 
             onSendMessage={(text) => onSendMessage(text, messages)}
             agentState={agentState}
             onOpenWorkbench={() => setIsPreviewOpen(true)}
           />
        </div>

        {/* Right Panel: Preview Area */}
        {isPreviewOpen && (
          <div className="flex-1 flex flex-col relative bg-transparent overflow-hidden">
             <PreviewPanel files={files} onClose={() => setIsPreviewOpen(false)} />
          </div>
        )}
      </div>
    </div>
  );
}
