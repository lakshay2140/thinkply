import React, { useEffect, useRef, useState } from 'react';
import { PromptInput } from '../ui/PromptInput';
import { Message } from '../../types';
import { Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import UserBubble from './UserBubble';
import { AgentState } from '../../App';
import { ArtifactCard } from './ArtifactCard';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const LOADING_PHRASES = [
  "Setting things up...",
  "Tightening a few screws...",
  "Adding the final touches...",
  "Connecting the pieces...",
  "Getting the details right...",
  "Making things click...",
  "Sprinkling some magic...",
  "Brewing something nice...",
  "Polishing the edges...",
  "Aligning the stars...",
  "Crunching the numbers...",
  "Firing up the engines...",
  "Painting the pixels...",
  "Orchestrating the code...",
  "Tuning the instruments...",
  "Gathering the resources...",
  "Connecting to the matrix...",
  "Assembling the components...",
  "Weaving the web...",
  "Preparing for launch..."
];

interface ChatPanelProps {
  messages: Message[];
  onSendMessage: (text: string) => void;
  agentState: AgentState;
  onOpenWorkbench?: () => void;
}

export function ChatPanel({ messages, onSendMessage, agentState, onOpenWorkbench }: ChatPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [loadingPhraseIndex, setLoadingPhraseIndex] = useState(0);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loadingPhraseIndex]);

  useEffect(() => {
    const isAnyGenerating = messages.some(m => m.isGenerating && !m.content);
    if (!isAnyGenerating) return;

    const interval = setInterval(() => {
      setLoadingPhraseIndex(prev => (prev + 1) % LOADING_PHRASES.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [messages]);

  const handleSubmit = async (text: string) => {
    onSendMessage(text);
  };

  return (
    <div className="flex flex-col h-full bg-transparent relative">
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar" ref={scrollRef}>
        <div className="flex flex-col gap-6 pt-20 pb-32">
          <AnimatePresence initial={false}>
            {messages.filter(m => !m.isHidden).map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full flex-shrink-0"
              >
                {msg.role === 'user' ? (
                  <UserBubble content={msg.content} />
                ) : (
                  <div className="flex gap-4 flex-row w-full">
                    <div className="w-8 h-8 flex items-center justify-center shrink-0 rounded-[8px] mt-0.5 bg-transparent">
                      <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center relative overflow-hidden">
                         {msg.isGenerating && (
                           <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                         )}
                        <Sparkles className="w-3.5 h-3.5 text-white relative z-10" />
                      </div>
                    </div>
                                        <div className="flex flex-col gap-1 w-full items-start overflow-hidden">
                      <span className="text-xs text-gray-400 font-medium flex items-center gap-2">
                        thinkply
                      </span>
                      <div className="w-full flex flex-col gap-2">
                        {msg.isGenerating && !msg.content ? (
                           <motion.span 
                             key={loadingPhraseIndex}
                             initial={{ opacity: 0, filter: 'blur(4px)' }}
                             animate={{ opacity: 1, filter: 'blur(0px)' }}
                             exit={{ opacity: 0, filter: 'blur(4px)' }}
                             className="text-[15px] text-indigo-300 font-medium tracking-wide drop-shadow-[0_0_8px_rgba(99,102,241,0.5)] mt-0.5"
                           >
                             {LOADING_PHRASES[loadingPhraseIndex]}
                           </motion.span>
                        ) : msg.messageParts && msg.messageParts.length > 0 ? (
                           msg.messageParts.map((part, idx) => {
                             if (part.type === 'text') {
                               if (!part.content) return null;
                               return (
                                 <div key={idx} className="text-[15px] leading-relaxed bg-transparent text-gray-200 mt-0.5 w-full max-w-full prose prose-invert prose-p:leading-relaxed prose-pre:p-0 prose-pre:bg-transparent break-words whitespace-normal text-ellipsis [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                                   <ReactMarkdown remarkPlugins={[remarkGfm]}>{part.content}</ReactMarkdown>
                                 </div>
                               );
                             } else if (part.type === 'artifact') {
                               return (
                                 <div key={idx} className="w-full pr-4 my-2">
                                   <ArtifactCard artifact={part.artifact} isGenerating={msg.isGenerating} onOpenWorkbench={onOpenWorkbench} />
                                 </div>
                               );
                             }
                           })
                        ) : (
                           <div className="text-[15px] leading-relaxed bg-transparent text-gray-200 mt-0.5 w-full max-w-full prose prose-invert prose-p:leading-relaxed prose-pre:p-0 prose-pre:bg-transparent break-words whitespace-normal text-ellipsis [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                             <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
                           </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
      
      <div className="absolute bottom-4 left-4 right-4 z-20">
        <PromptInput onSubmit={handleSubmit} compact={true} agentState={agentState} />
      </div>
    </div>
  );
}
