import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface CollapsibleProps {
  content: string;
  fadeFrom?: string;
  align?: 'end' | 'start';
}

export default function Collapsible({ content, fadeFrom = 'from-[#161616]', align = 'start' }: CollapsibleProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isOverflowing, setIsOverflowing] = useState(false);
  const [collapsedHeight, setCollapsedHeight] = useState<number>(72);
  const [fullHeight, setFullHeight] = useState<number | 'auto'>('auto');
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (contentRef.current) {
      const scrollHeight = contentRef.current.scrollHeight;
      const lineHeight = parseFloat(getComputedStyle(contentRef.current).lineHeight) || 24;
      const maxLinesHeight = lineHeight * 3;
      
      if (scrollHeight > maxLinesHeight * 1.2) {
        setIsOverflowing(true);
        setCollapsedHeight(maxLinesHeight);
        setFullHeight(scrollHeight);
      } else {
        setIsOverflowing(false);
        setFullHeight(scrollHeight);
      }
    }
  }, [content]);

  return (
    <div className="relative flex flex-col w-full">
      <motion.div 
        animate={{ height: isExpanded ? fullHeight : (isOverflowing ? collapsedHeight : fullHeight) }}
        initial={false}
        transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
        className="relative overflow-hidden"
      >
        <div ref={contentRef} className="text-[15px] leading-relaxed whitespace-pre-wrap text-gray-200 pb-1">
          {content}
        </div>
        
        <AnimatePresence>
          {!isExpanded && isOverflowing && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`absolute bottom-0 left-0 w-full h-12 bg-gradient-to-t ${fadeFrom} to-transparent pointer-events-none`} 
            />
          )}
        </AnimatePresence>
      </motion.div>

      {isOverflowing && (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`group flex items-center gap-1.5 text-[11px] font-medium text-gray-300 hover:text-white transition-all bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-full border border-white/10 backdrop-blur-md self-${align === 'end' ? 'end' : 'start'} mt-2 shadow-sm`}
        >
          {isExpanded ? (
            <>
              Show less <ChevronUp className="w-3.5 h-3.5 text-gray-400 group-hover:text-white transition-colors" />
            </>
          ) : (
            <>
              Show more <ChevronDown className="w-3.5 h-3.5 text-gray-400 group-hover:text-white transition-colors" />
            </>
          )}
        </button>
      )}
    </div>
  );
}
