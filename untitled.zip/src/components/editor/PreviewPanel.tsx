import { useState } from 'react';
import { RefreshCw, Monitor, Smartphone, Maximize2, Minimize2, Lock, Code2, Play, Eye, Code, Copy, ExternalLink, Download, RotateCw, X } from 'lucide-react';
import { motion } from 'motion/react';
import { 
  SandpackProvider, 
  SandpackLayout, 
  SandpackCodeEditor, 
  SandpackPreview,
  SandpackFileExplorer
} from "@codesandbox/sandpack-react";

interface PreviewPanelProps {
  files?: Record<string, string>;
  activeTab?: 'preview' | 'code';
  onClose?: () => void;
}

const customSetup = {
  dependencies: {
    "lucide-react": "latest",
    "motion": "latest",
    "tailwindcss": "^3.4.0",
    "react-router-dom": "latest"
  }
};

export function PreviewPanel({ files = {}, activeTab: defaultTab = 'preview', onClose }: PreviewPanelProps) {
  const [activeTab, setActiveTab] = useState<'code' | 'preview'>(defaultTab);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const defaultFiles = {
    "/App.tsx": "export default function App() {\n  return (\n    <div style={{ fontFamily: 'system-ui', padding: 40, color: '#fff', background: '#1e1e20', height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>\n      <h1 style={{ fontSize: '2rem', marginBottom: '1rem', background: 'linear-gradient(to right, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>Welcome to Your AI Builder</h1>\n      <p style={{ color: '#9ca3af' }}>Type a prompt in the chat panel to generate a new application.</p>\n    </div>\n  );\n}\n"
  };

  const sandpackFiles = Object.keys(files).length > 0 
    ? Object.fromEntries(Object.entries(files).map(([k, v]) => {
        let content = v;
        if (k.endsWith('/package.json') || k === 'package.json') {
          try {
            const pkg = JSON.parse(v);
            content = JSON.stringify(pkg, null, 2);
          } catch(e) {}
        }
        return [k.replace(/^\//, ''), content]
      }))
    : defaultFiles;

  return (
    <div className={`flex flex-col bg-[#1e1e20] text-gray-200 overflow-hidden pointer-events-auto transition-all duration-300 ease-in-out ${isFullscreen ? 'fixed inset-0 z-[100] w-[100vw] h-[100vh]' : 'h-full w-full shadow-2xl'}`}>
      <SandpackProvider 
        key={refreshKey}
        template="vite-react-ts"
        theme="dark"
        files={sandpackFiles}
        customSetup={customSetup}
      >
        <div 
          className="flex-shrink-0 cursor-grab active:cursor-grabbing flex items-center justify-center pt-2 pb-2 w-full touch-none relative z-10"
        >
          <div className="w-12 h-1.5 bg-white/20 hover:bg-white/30 transition-colors rounded-full pointer-events-none"></div>
        </div>

        {/* Editor/Preview Toolbar */}
        <div className="flex items-center justify-between px-4 pb-2 border-b border-white/10 flex-shrink-0">
          <div className="flex items-center gap-4">
            <div className="flex bg-black/40 p-1 rounded-lg border border-white/5">
              <button 
                onClick={() => setActiveTab('code')}
                className={`px-4 py-1.5 rounded-md text-[13px] font-medium transition-all ${
                  activeTab === 'code' 
                    ? 'bg-white/10 text-white shadow-sm' 
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Code
              </button>
              <button 
                onClick={() => setActiveTab('preview')}
                className={`px-4 py-1.5 rounded-md text-[13px] font-medium transition-all ${
                  activeTab === 'preview' 
                    ? 'bg-white/10 text-white shadow-sm' 
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                Preview
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {activeTab === 'preview' && (
              <>
                <button 
                  className="p-1.5 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-2 px-3"
                  title="Download Project (ZIP)"
                >
                  <Download size={14} />
                  <span className="text-xs font-medium hidden sm:block">Export</span>
                </button>
                <button 
                  onClick={handleRefresh}
                  className="p-1.5 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-2 px-3"
                  title="Refresh Preview"
                >
                  <RotateCw size={14} />
                  <span className="text-xs font-medium hidden sm:block">Sync</span>
                </button>
                <button 
                  onClick={handleFullscreen}
                  className="p-1.5 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                  title={isFullscreen ? "Exit Full Screen" : "Full Screen"}
                >
                  {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                </button>
              </>
            )}
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors ml-1"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden relative bg-transparent flex flex-col">
          <SandpackLayout className="h-full w-full bg-transparent border-none rounded-none flex !flex-row flex-1 overflow-hidden">
            {activeTab === 'code' && (
              <>
                <div className="w-64 shrink-0 border-r border-white/10 h-full hidden md:block bg-[#121214] text-gray-300">
                  <SandpackFileExplorer />
                </div>
                <div className="flex-1 h-full min-w-0 [&_.sp-tabs]:border-b [&_.sp-tabs]:border-white/10 bg-[#1e1e20] text-gray-300 [&_.sp-wrapper]:!bg-transparent [&_.cm-editor]:!bg-transparent [&_.cm-gutters]:!bg-transparent [&_.cm-gutters]:!text-gray-500 [&_.cm-activeLine]:!bg-white/5">
                  <SandpackCodeEditor showTabs={true} showLineNumbers={true} showInlineErrors={true} />
                </div>
              </>
            )}
            
            {activeTab === 'preview' && (
              <div id="sandpack-preview-container" className="flex-1 w-full relative h-full bg-white">
                <SandpackPreview 
                  showOpenInCodeSandbox={false} 
                  showRefreshButton={false} 
                  className="absolute inset-0 w-full h-full border-0 bg-white"
                />
              </div>
            )}
          </SandpackLayout>
        </div>
      </SandpackProvider>
    </div>
  );
}
