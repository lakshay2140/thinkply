import React, { useState, useEffect } from 'react';
import { BoltArtifact } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, ChevronRight, Terminal, FileCode, Check } from 'lucide-react';

interface ArtifactCardProps {
  artifact: BoltArtifact;
  isGenerating?: boolean;
  onOpenWorkbench?: () => void;
}

export function ArtifactCard({ artifact, isGenerating, onOpenWorkbench }: ArtifactCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [userToggled, setUserToggled] = useState(false);

  // Auto-expand when finished if not user toggled
  useEffect(() => {
    if (!isGenerating && artifact.actions.length > 0 && !isExpanded && !userToggled) {
      setIsExpanded(true);
    }
  }, [isGenerating, artifact.actions.length, isExpanded, userToggled]);

  const toggleActions = () => {
    setUserToggled(true);
    setIsExpanded(!isExpanded);
  };

  const dynamicTitle = isGenerating ? 'Creating Project...' : artifact.title || 'Project Created';

  return (
    <div className="w-full mt-3 rounded-xl border border-white/10 bg-[#1e1e20]/60 backdrop-blur-xl overflow-hidden transition-all duration-150 shadow-2xl">
      <div className="flex">
        <button 
          className="flex items-stretch bg-transparent hover:bg-white/5 w-full overflow-hidden transition-colors cursor-pointer"
          onClick={() => {
            if (onOpenWorkbench) onOpenWorkbench();
          }}
        >
          <div className="px-4 py-3.5 w-full text-left">
            <div className="w-full text-gray-200 font-semibold text-sm">
              {dynamicTitle}
            </div>
            <div className="w-full text-gray-500 text-xs mt-0.5">
              Click to open Workbench
            </div>
          </div>
        </button>
        
        <AnimatePresence>
          {artifact.actions.length > 0 && (
            <motion.button
              initial={{ width: 0 }}
              animate={{ width: 'auto' }}
              exit={{ width: 0 }}
              transition={{ duration: 0.15 }}
              className="bg-transparent hover:bg-white/5 transition-colors border-l border-white/5 flex items-center justify-center p-3 text-gray-500 hover:text-gray-300"
              onClick={toggleActions}
            >
              {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {isExpanded && artifact.actions.length > 0 && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden bg-black/20"
          >
            <div className="bg-white/5 h-[1px]" />
            <div className="p-4 text-left">
              <ul className="list-none space-y-3 m-0 p-0">
                {artifact.actions.map((action, idx) => {
                  const isActionInProgress = isGenerating && idx === artifact.actions.length - 1;
                  
                  return (
                    <motion.li 
                      key={idx}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex flex-col"
                    >
                      <div className="flex items-center gap-2.5 text-sm">
                        <div className={`flex-shrink-0 ${isActionInProgress ? 'text-indigo-400' : 'text-emerald-500'}`}>
                          {isActionInProgress ? (
                             <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin" />
                          ) : (
                             <Check size={14} strokeWidth={3} />
                          )}
                        </div>
                        
                        {action.type === 'file' ? (
                          <div className="text-gray-300 flex items-center flex-wrap gap-1.5">
                            Create{' '}
                            <code className="bg-[#2D2B55]/50 text-[#a594fd] px-1.5 py-0.5 rounded text-[12px] font-mono border border-[#a594fd]/20">
                              {action.filePath}
                            </code>
                          </div>
                        ) : action.type === 'edit' ? (
                          <div className="text-gray-300 flex items-center flex-wrap gap-1.5">
                            Edit{' '}
                            <code className="bg-[#2D2B55]/50 text-[#a594fd] px-1.5 py-0.5 rounded text-[12px] font-mono border border-[#a594fd]/20">
                              {action.filePath}
                            </code>
                          </div>
                        ) : action.type === 'read' ? (
                          <div className="text-gray-300 flex items-center flex-wrap gap-1.5">
                            Read{' '}
                            <code className="bg-[#2D2B55]/50 text-[#a594fd] px-1.5 py-0.5 rounded text-[12px] font-mono border border-[#a594fd]/20">
                              {action.filePath}
                            </code>
                          </div>
                        ) : action.type === 'explore' ? (
                          <div className="text-gray-300 flex items-center flex-wrap gap-1.5">
                            Explore{' '}
                            <code className="bg-[#2D2B55]/50 text-[#a594fd] px-1.5 py-0.5 rounded text-[12px] font-mono border border-[#a594fd]/20">
                              {action.dirPath}
                            </code>
                          </div>
                        ) : action.type === 'shell' ? (
                          <div className="text-gray-300">Run command</div>
                        ) : action.type === 'start' ? (
                          <div className="text-gray-300">Start Application</div>
                        ) : null}
                      </div>

                      {(action.type === 'shell' || action.type === 'start') && action.content && (
                        <div className="mt-2 pl-6">
                          <div className="bg-[#121214]/80 border border-white/5 text-gray-400 p-2.5 rounded-lg text-xs font-mono overflow-x-auto whitespace-pre">
                            {action.content.split('\n')[0]}{action.content.split('\n').length > 1 ? '\n...' : ''}
                          </div>
                        </div>
                      )}
                    </motion.li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
