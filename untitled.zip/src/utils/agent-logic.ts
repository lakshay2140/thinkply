import { BoltArtifact, BoltAction } from '../types';

export type MessagePart = { type: 'text', content: string } | { type: 'artifact', artifact: BoltArtifact };

export function parseBoltArtifacts(text: string, currentFiles: Record<string, string> = {}): { text: string; artifacts: BoltArtifact[]; files: Record<string, string>, messageParts: MessagePart[] } {
  const artifacts: BoltArtifact[] = [];
  const files: Record<string, string> = { ...currentFiles };
  const messageParts: MessagePart[] = [];
  
  let cleanText = text;
  let lastIndex = 0;
  
  // Find <boltArtifact> tags (even unclosed ones)
  const artifactRegex = /<boltArtifact([^>]*)>([\s\S]*?)(?:<\/boltArtifact>|$)/g;
  let artifactMatch;
  
  while ((artifactMatch = artifactRegex.exec(text)) !== null) {
    if (artifactMatch.index > lastIndex) {
      messageParts.push({ type: 'text', content: text.substring(lastIndex, artifactMatch.index) });
    }
    
    const attrs = artifactMatch[1];
    const content = artifactMatch[2];
    
    const titleMatch = attrs.match(/title="([^"]*)"/);
    const idMatch = attrs.match(/id="([^"]*)"/);
    
    const artifact: BoltArtifact = {
      title: titleMatch ? titleMatch[1] : '',
      id: idMatch ? idMatch[1] : `artifact-${Date.now()}`,
      actions: []
    };
    
    const actionRegex = /<boltAction([^>]*)>([\s\S]*?)(?:<\/boltAction>|$)/g;
    let actionMatch;
    
    while ((actionMatch = actionRegex.exec(content)) !== null) {
      const actionAttrs = actionMatch[1];
      const actionContent = actionMatch[2];
      
      const typeMatch = actionAttrs.match(/type="([^"]*)"/);
      const filePathMatch = actionAttrs.match(/filePath="([^"]*)"/);
      const dirPathMatch = actionAttrs.match(/dirPath="([^"]*)"/);
      
      const type = typeMatch ? typeMatch[1] as any : 'shell';
      const filePath = filePathMatch ? filePathMatch[1] : undefined;
      const dirPath = dirPathMatch ? dirPathMatch[1] : undefined;
      
      artifact.actions.push({
        type,
        filePath,
        dirPath,
        content: actionContent.replace(/^[ \t]*```[-a-zA-Z]*\n/gm, '').replace(/\n[ \t]*```[ \t]*$/gm, '').trim()
      });
      
      if (type === 'file' && filePath) {
        files[filePath] = actionContent
          .replace(/^[ \t]*```[-a-zA-Z]*\n/gm, '')
          .replace(/\n[ \t]*```[ \t]*$/gm, '')
          .trimStart();
      } else if (type === 'edit' && filePath && files[filePath]) {
        const searchMatch = actionContent.match(/<search>\s*([\s\S]*?)\s*<\/search>/);
        const replaceMatch = actionContent.match(/<replace>\s*([\s\S]*?)\s*<\/replace>/);
        if (searchMatch && replaceMatch) {
          const search = searchMatch[1];
          const replace = replaceMatch[1];
          // Replace using literal string replacement
          files[filePath] = files[filePath].replace(search, replace);
        }
      }
    }
    
    artifacts.push(artifact);
    messageParts.push({ type: 'artifact', artifact });
    
    // Remove artifact from text to show clean response
    cleanText = cleanText.replace(artifactMatch[0], '');
    lastIndex = artifactRegex.lastIndex;
  }
  
  if (lastIndex < text.length) {
    messageParts.push({ type: 'text', content: text.substring(lastIndex) });
  }
  
  return { text: cleanText, artifacts, files, messageParts };
}
