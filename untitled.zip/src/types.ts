import { MessagePart } from './utils/agent-logic';

export interface BoltAction {
  type: 'file' | 'shell' | 'start' | 'edit' | 'read' | 'explore';
  filePath?: string;
  dirPath?: string;
  content: string;
}

export interface BoltArtifact {
  title: string;
  id: string;
  actions: BoltAction[];
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isGenerating?: boolean;
  artifacts?: BoltArtifact[];
  messageParts?: MessagePart[];
  isHidden?: boolean;
}

export interface Project {
  id: string;
  name: string;
  date: string;
  isStarred: boolean;
  hasPreview?: boolean;
}
