import { useState, useEffect } from 'react';
import { NavDrawer } from './components/layout/NavDrawer';
import { HomeView } from './components/home/HomeView';
import { EditorView } from './components/editor/EditorView';
import { ProjectsView } from './components/projects/ProjectsView';
import { Message } from './types';
import { parseBoltArtifacts } from './utils/agent-logic';

export type AgentState = 'running' | 'waiting' | 'sleeping' | 'waking' | 'initial';

export default function App() {
  const [appState, setAppState] = useState<'home' | 'editing' | 'projects' | 'starred'>('home');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [files, setFiles] = useState<Record<string, string>>({
    'package.json': JSON.stringify({
      "name": "vite-react-ts",
      "private": true,
      "version": "0.0.0",
      "type": "module",
      "scripts": {
        "dev": "vite",
        "build": "tsc && vite build",
        "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
        "preview": "vite preview"
      },
      "dependencies": {
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "lucide-react": "latest",
        "motion": "latest",
        "tailwindcss": "^3.4.0",
        "react-router-dom": "latest"
      },
      "devDependencies": {
        "@types/react": "^18.2.43",
        "@types/react-dom": "^18.2.17",
        "@vitejs/plugin-react": "^4.0.3",
        "typescript": "^5.2.2",
        "vite": "^4.4.5"
      }
    }, null, 2),
    'index.html': `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Vite + React + TS</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`,
    'vite.config.ts': `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
})`,
    'src/main.tsx': `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)`,
    'src/App.tsx': `export default function App() {\n  return (\n    <div style={{ fontFamily: 'system-ui', padding: 40, color: '#fff', background: '#1e1e20', height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>\n      <h1 style={{ fontSize: '2rem', marginBottom: '1rem', background: 'linear-gradient(to right, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>Welcome to Your AI Builder</h1>\n      <p style={{ color: '#9ca3af' }}>Type a prompt in the chat panel to generate a new application.</p>\n    </div>\n  );\n}\n`,
    'src/index.css': `@tailwind base;\n@tailwind components;\n@tailwind utilities;\n`
  });
  const [projectName, setProjectName] = useState<string>('New Project');
  const [agentState, setAgentState] = useState<AgentState>('initial');
  const [lastActivity, setLastActivity] = useState<number>(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      if ((agentState === 'waiting' || agentState === 'initial') && Date.now() - lastActivity > 5 * 60 * 1000) {
        setAgentState('sleeping');
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [agentState, lastActivity]);

  const sendMessage = async (prompt: string, existingMessages: Message[] = [], isHidden: boolean = false) => {
    if (agentState === 'sleeping' || agentState === 'initial') {
      setAgentState('waking');
      await new Promise(r => setTimeout(r, 800));
    }
    
    setLastActivity(Date.now());
    setAgentState('running');
    
    const newMessages = [...existingMessages, { id: Date.now().toString(), role: 'user' as const, content: prompt, isHidden }];
    setMessages(newMessages);
    setAppState('editing');
    
    const placeholderId = (Date.now() + 1).toString();
    setMessages(prev => [
      ...prev,
      { 
        id: placeholderId, 
        role: 'assistant', 
        content: '',
        isGenerating: true
      }
    ]);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          messages: newMessages.map(m => ({ role: m.role, content: m.content }))
        })
      });

      if (!response.body) throw new Error('No response body');
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullContent = '';
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split('\n\n');
        buffer = parts.pop() || '';
        
        for (const part of parts) {
          const trimmedLine = part.trim();
          if (trimmedLine.startsWith('data: ') && trimmedLine !== 'data: [DONE]') {
            try {
              const data = JSON.parse(trimmedLine.substring(6));
              if (data.content) {
                fullContent += data.content;
                const parsed = parseBoltArtifacts(fullContent, files);
                if (parsed.artifacts.length > 0 && parsed.artifacts[0].title) {
                  setProjectName(parsed.artifacts[0].title);
                }
                if (Object.keys(parsed.files).length > 0) {
                   setFiles(prev => ({ ...prev, ...parsed.files }));
                }
                setMessages(prev => prev.map(m => m.id === placeholderId ? { ...m, content: parsed.text, artifacts: parsed.artifacts, messageParts: parsed.messageParts } : m));
              }
            } catch (e) {
              console.error("Error parsing JSON:", e, trimmedLine);
            }
          }
        }
      }
      
      const parsedOutput = parseBoltArtifacts(fullContent, files);
      setMessages(prev => prev.map(m => m.id === placeholderId ? { ...m, isGenerating: false } : m));
      setAgentState('waiting');
      setLastActivity(Date.now());
      
      let autoRespondPrompt = '';
      if (parsedOutput.artifacts.length > 0) {
        const lastArtifact = parsedOutput.artifacts[parsedOutput.artifacts.length - 1];
        if (lastArtifact.actions.length > 0) {
          const lastAction = lastArtifact.actions[lastArtifact.actions.length - 1];
          if (lastAction.type === 'read' && lastAction.filePath) {
            const fileContent = parsedOutput.files[lastAction.filePath];
            autoRespondPrompt = `[System] Result of reading ${lastAction.filePath}:\n\`\`\`\n${fileContent !== undefined ? fileContent : 'File not found.'}\n\`\`\``;
          } else if (lastAction.type === 'explore' && lastAction.dirPath) {
            const allFiles = Object.keys(parsedOutput.files);
            const matched = allFiles.filter(f => f.startsWith(lastAction.dirPath!));
            autoRespondPrompt = `[System] Directory contents of ${lastAction.dirPath}:\n${matched.length ? matched.join('\n') : 'Directory is empty or not found.'}`;
          }
        }
      }
      
      if (autoRespondPrompt) {
        // Send internal message automatically
        setTimeout(() => sendMessage(autoRespondPrompt, [...newMessages, { id: placeholderId, role: 'assistant', content: fullContent, artifacts: parsedOutput.artifacts, messageParts: parsedOutput.messageParts }], true), 500);
      }
      
    } catch (err) {
      console.error(err);
      setMessages(prev => prev.map(m => m.id === placeholderId ? { ...m, content: "Error communicating with agent.", isGenerating: false } : m));
      setAgentState('waiting');
    }
  };

  const handleStart = async (prompt: string) => {
    setMessages([]);
    setFiles({
      'package.json': JSON.stringify({
        "name": "vite-react-ts",
        "private": true,
        "version": "0.0.0",
        "type": "module",
        "scripts": {
          "dev": "vite",
          "build": "tsc && vite build",
          "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
          "preview": "vite preview"
        },
        "dependencies": {
          "react": "^18.2.0",
          "react-dom": "^18.2.0",
          "lucide-react": "latest",
          "motion": "latest",
          "tailwindcss": "^3.4.0",
          "react-router-dom": "latest"
        },
        "devDependencies": {
          "@types/react": "^18.2.43",
          "@types/react-dom": "^18.2.17",
          "@vitejs/plugin-react": "^4.0.3",
          "typescript": "^5.2.2",
          "vite": "^4.4.5"
        }
      }, null, 2),
      'index.html': `<!doctype html>\n<html lang="en">\n  <head>\n    <meta charset="UTF-8" />\n    <link rel="icon" type="image/svg+xml" href="/vite.svg" />\n    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n    <title>Vite + React + TS</title>\n  </head>\n  <body>\n    <div id="root"></div>\n    <script type="module" src="/src/main.tsx"></script>\n  </body>\n</html>`,
      'vite.config.ts': `import { defineConfig } from 'vite'\nimport react from '@vitejs/plugin-react'\n\n// https://vitejs.dev/config/\nexport default defineConfig({\n  plugins: [react()],\n})`,
      'src/main.tsx': `import React from 'react'\nimport ReactDOM from 'react-dom/client'\nimport App from './App.tsx'\nimport './index.css'\n\nReactDOM.createRoot(document.getElementById('root')!).render(\n  <React.StrictMode>\n    <App />\n  </React.StrictMode>,\n)`,
      'src/App.tsx': `export default function App() {\n  return (\n    <div style={{ fontFamily: 'system-ui', padding: 40, color: '#fff', background: '#1e1e20', height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>\n      <h1 style={{ fontSize: '2rem', marginBottom: '1rem', background: 'linear-gradient(to right, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', color: 'transparent' }}>Welcome to Your AI Builder</h1>\n      <p style={{ color: '#9ca3af' }}>Type a prompt in the chat panel to generate a new application.</p>\n    </div>\n  );\n}\n`,
      'src/index.css': `@tailwind base;\n@tailwind components;\n@tailwind utilities;\n`
    });
    setProjectName('New Project');
    await sendMessage(prompt, []);
  };

  return (
    <div className="flex bg-[#0A0612] text-white h-screen w-full overflow-hidden antialiased font-sans selection:bg-indigo-500/30 selection:text-white">
      <NavDrawer 
        isOpen={isNavOpen} 
        onClose={() => setIsNavOpen(false)} 
        onNavigate={(view) => setAppState(view)}
        currentView={appState}
      />
      {appState === 'home' ? (
        <HomeView onMenuClick={() => setIsNavOpen(true)} onStart={handleStart} />
      ) : appState === 'projects' || appState === 'starred' ? (
        <ProjectsView onMenuClick={() => setIsNavOpen(true)} filter={appState === 'starred' ? 'starred' : 'all'} />
      ) : (
        <EditorView 
          onMenuClick={() => setIsNavOpen(true)} 
          isNavOpen={isNavOpen}
          messages={messages} 
          onSendMessage={(text) => sendMessage(text, messages)}
          files={files}
          setFiles={setFiles}
          projectName={projectName}
          setProjectName={setProjectName}
          agentState={agentState}
        />
      )}
    </div>
  );
}
