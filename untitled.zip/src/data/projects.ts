export const DUMMY_PROJECTS = [
  { id: '1', name: 'New Project', date: 'May 31', isStarred: true },
  { id: '2', name: 'ChatGPT Website Structure', date: 'May 29', isStarred: false, hasPreview: true },
  { id: '3', name: 'Blank (duplicated)', date: 'May 23', isStarred: false },
  { id: '4', name: 'Portfolio Template', date: 'May 10', isStarred: true },
  { id: '5', name: 'Dashboard UI', date: 'May 05', isStarred: false },
  { id: '6', name: 'E-commerce Store', date: 'Apr 28', isStarred: false },
];
