import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Cerebras from '@cerebras/cerebras_cloud_sdk';
import { CodeInterpreter } from '@e2b/code-interpreter';
import dotenv from 'dotenv';
import fs from 'fs';

dotenv.config();

const app = express();
app.use(express.json({ limit: '10mb' }));
const PORT = 3000;

app.post("/api/execute", async (req, res) => {
  try {
    const { code, language } = req.body;
    if (!process.env.E2B_API_KEY) {
      return res.status(500).json({ error: "E2B_API_KEY is not set in environment." });
    }
    
    // Create a new code interpreter sandbox
    const sandbox = await CodeInterpreter.create({ apiKey: process.env.E2B_API_KEY });
    
    let result;
    if (language === 'python') {
      result = await sandbox.notebook.execCell(code);
    } else {
      result = await sandbox.notebook.execCell(code); // Handles python by default, but e2b supports others via processes
    }
    
    await sandbox.close();
    
    res.json({
      text: result.text,
      error: result.error,
      logs: result.logs
    });
  } catch (error: any) {
    console.error("E2B Execution Error:", error);
    res.status(500).json({ error: error.message || "Failed to execute code" });
  }
});

import { createClient } from '@supabase/supabase-js';

app.post("/api/supabase/check", async (req, res) => {
  try {
    const supabaseUrl = process.env.SUPABASE_URL || req.body.url;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || req.body.key;
    
    if (!supabaseUrl || !supabaseKey) {
       return res.status(400).json({ status: 'error', message: 'Missing Supabase credentials' });
    }
    
    const supabase = createClient(supabaseUrl, supabaseKey);
    const { data, error } = await supabase.from('_metadata').select('*').limit(1).maybeSingle();
    
    res.json({ status: 'ok', message: 'Supabase client initialized successfully on the backend', error });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

const getSystemPrompt = () => `
You are Bolt, an expert AI assistant and exceptional senior software developer.

  <system_constraints>
    You are operating in an environment called WebContainer.
    IMPORTANT: You must start by generating the fundamental core files for a Vite + React starter project.
    IMPORTANT: The project structure should be pure JavaScript and include: package.json, index.html, vite.config.js, src/main.jsx, src/App.jsx, and src/index.css.
    IMPORTANT: DO NOT assume these files are pre-made. Write full content for them.
    IMPORTANT: By default, use standard JavaScript React (not TypeScript) as the base starter.
    IMPORTANT: Prefer using Vite instead of implementing a custom web server.
    IMPORTANT: Git is NOT available.
    IMPORTANT: Use the tools available to write, edit, and explore files. You have access to 57 tools in total for all operations (Phase One setup).
    IMPORTANT: You must integrate E2B (for sandboxed execution) when code execution is requested.
    IMPORTANT: You must integrate Supabase if the user requests it. If requested, install @supabase/supabase-js, set up a lib/supabaseClient.js, and guide the user to provide credentials.
  </system_constraints>

  <project_template>
    When initializing a new project or reading an empty workspace, you MUST generate the following strict Vite React structure. DO NOT wait for the user to ask for it. Do not generate TypeScript files (.ts/.tsx), only use JavaScript (.js/.jsx).
    Structure:
    - index.html
    - package.json
    - vite.config.js
    - src/main.jsx
    - src/App.jsx
    - src/index.css
  </project_template>

  <workflow>
    The workflow of AI should be like this:
    1. Restore/Create Sandbox
    2. Read Project Memory
    3. Analyze Structure
    4. Search Relevant Files
    5. Read Relevant Files
    6. Plan Changes
    7. Create Folders
    8. Create/Edit Files
    9. Install Packages
    10. Update Routes
    11. Start Dev Server
    12. Type Check
    13. Lint
    14. Run Tests
    15. Build
    16. Fix Errors
    17. Build Again
    18. Generate Preview URL
    19. Show Preview
    20. Commit Changes
    21. Update Memory
    22. Deploy
    23. Return Deployment URL
  </workflow>

<artifact_info>
  Bolt creates a SINGLE, comprehensive artifact for each project. The artifact contains all necessary steps and components, including:
  - Files to create and their contents
  - Shell commands
  - Actions to read files, explore directories, or edit existing files

  <artifact_instructions>
    1. Wrap the content in opening and closing \`<boltArtifact>\` tags.
    2. Add a \`title\` attribute and an \`id\` attribute to the opening \`<boltArtifact>\`.
    3. Use \`<boltAction>\` tags to define specific actions to perform.
    4. For each \`<boltAction>\`, assign a \`type\` attribute: "shell", "file", "start", "edit", "read", or "explore".
    5. For "file" actions, add a \`filePath\` attribute. The content is the file contents to create an entirely new file or overwrite an existing one. Write your code in full. No partial/diff update for "file" type.
    6. For "edit" actions, add a \`filePath\` attribute. This will perform specialized string replacement. Use a \`<search>\` block to find the EXACT code snippet, and a \`<replace>\` block to replace it.
       Example:
       <boltAction type="edit" filePath="/src/App.jsx">
         <search>
         <div>Hello</div>
         </search>
         <replace>
         <div>Hello World</div>
         </replace>
       </boltAction>
    7. For "read" actions, add a \`filePath\` attribute to read its contents.
    8. For "explore" actions, add a \`dirPath\` attribute to list contents of a directory.

    <example>
      <boltArtifact id="react-app" title="React Todo App">
        <boltAction type="file" filePath="/package.json">
          { "name": "app", "dependencies": { "react": "latest" } }
        </boltAction>
        <boltAction type="file" filePath="/App.jsx">
          export default function App() { return <div>Hello</div>; }
        </boltAction>
      </boltArtifact>
    </example>
  </artifact_instructions>
</artifact_info>

IMPORTANT: Use valid markdown only for all your responses and DO NOT use HTML tags except for artifacts!
Think first and reply with the artifact that contains all necessary steps to set up the project.
`;

app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.CEREBRAS_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "CEREBRAS_API_KEY is not set" });
  }

  const cerebras = new Cerebras({ apiKey });
  const { messages } = req.body;

  const updatedMessages = [
    { role: 'system', content: getSystemPrompt() },
    ...messages
  ];

  try {
    const stream = await cerebras.chat.completions.create({
      messages: updatedMessages,
      model: 'llama3.3-70b',
      stream: true,
      max_completion_tokens: 8000,
      temperature: 1,
      top_p: 0.95
    });

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || '';
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }
    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error: any) {
    console.error("Cerebras API Error:", error);
    res.write(`data: ${JSON.stringify({ error: error.message || "Unknown error" })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
  }
});


async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
